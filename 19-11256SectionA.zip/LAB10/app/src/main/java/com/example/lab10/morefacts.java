package com.example.lab10;

import android.os.Bundle;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class morefacts extends AppCompatActivity implements View.OnClickListener {

    ArrayList<String> animalNames = new ArrayList<>();

    String fct = "hello";
    Button more;
    String res;
    RVAdapter adapter;
    private List<Person> persons;


    LinearLayout parent;
    RVAdapter rvAdapter;
    RecyclerView rv;

    TextView text;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_morefacts);

        text=findViewById(R.id.facte);
        more=findViewById(R.id.more);
        more.setOnClickListener(this);


        rv = findViewById(R.id.rv);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        rv.setLayoutManager(linearLayoutManager);


        persons = new ArrayList<>();

        rvAdapter = new RVAdapter(persons);

        rv.setAdapter(rvAdapter);










        for (int ok = 0; ok <= 10; ok++) {

            RequestQueue queue = Volley.newRequestQueue(this);
            String url ="http://numbersapi.com/random/math?json";

            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            try {

                                JSONObject jObject = new JSONObject(response);
                                String str = jObject.getString("text");

                                persons.add(new Person(str, str));
                                rvAdapter.notifyDataSetChanged();

                                Log.d("Facts", str);

                            }
                            catch(Exception e)
                            {

                            }

                        }

                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    text.setText("That didn't work!");
                }
            });


            queue.add(stringRequest);


        }

        //animalNames.add(res);

    }













   /* @Override
    public void onItemClick(View view, int position) {
        Toast.makeText(this, "You clicked " + adapter.getItem(position) + " on row number " + position, Toast.LENGTH_SHORT).show();
    }*/

    @Override
    public void onClick(View v) {
        //final ArrayList<String> animalNames = new ArrayList<>();
        if(v.getId()==R.id.more) {

            for (int ok = 0; ok <= 10; ok++) {

// Instantiate the RequestQueue.
                RequestQueue queue = Volley.newRequestQueue(this);
                String url = "http://numbersapi.com/random/math";

// Request a string response from the provided URL.
                StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                        new Response.Listener<String>() {
                            @Override

                            public void onResponse(String response) {
                                final int n = response.length();
                                //res=response;
                                // Display the first 500 characters of the response string.
                                //res=String.valueOf(response);
                                text.setText(response.substring(0, n));
                                res = String.valueOf(response);

                                persons.add(new Person(res, res));
                                rvAdapter.notifyDataSetChanged();

                                //fct=response.substring(0,n);

                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        text.setText("That didn't work!");
                    }
                });

// Add the request to the RequestQueue.
                queue.add(stringRequest);
                // animalNames.add(res + "whatever");


            }

        }
        Log.d("heloo", ""+res);
    }
}



















/*for (int ok = 0; ok <= 10; ok++) {

// Instantiate the RequestQueue.
            RequestQueue queue = Volley.newRequestQueue(this);
            String url = "http://numbersapi.com/random/math";

// Request a string response from the provided URL.
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override

                        public void onResponse(String response) {
                            final int n = response.length();
                            // Display the first 500 characters of the response string.
                            text.setText(response.substring(0, n));
                            facts.add(new facts(response.substring(0, n)));

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    text.setText("That didn't work!");
                }
            });

// Add the request to the RequestQueue.
            queue.add(stringRequest);


        }
    }*/