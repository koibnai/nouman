package com.example.lab10;

import java.util.List;

class Person {
    String name;
    String age;

    Person(String name, String age) {
        this.name = name;
        this.age = age;
    }
}
