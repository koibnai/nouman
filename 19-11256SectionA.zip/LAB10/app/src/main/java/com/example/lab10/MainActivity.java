package com.example.lab10;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    TextView text2,text;
    ImageView image;
    Button more,math;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text2 = findViewById(R.id.text2);
        text=findViewById(R.id.text);
        image=findViewById(R.id.image);
        image.setOnClickListener(this);
        more=findViewById(R.id.more);
        more.setOnClickListener(this);
        math=findViewById(R.id.math);
        math.setOnClickListener(this);


        final TextView textView = (TextView) findViewById(R.id.text);
// ...

// Instantiate the RequestQueue.
        RequestQueue queue = Volley.newRequestQueue(this);
        String url ="http://numbersapi.com/random/math?json";

// Request a string response from the provided URL.
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            // Display the first 500 characters of the response string.

                            JSONObject jObject = new JSONObject(response);
                            //You can then extract the entire data array:
                           // Log.d("p", "" + jObject.getString("text"));
                            String str = jObject.getString("text");
                            text.setText(str);
                        }
                        catch(Exception e)
                        {

                        }

                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                text.setText("That didn't work!");
            }
        });

// Add the request to the RequestQueue.
        queue.add(stringRequest);


        RequestQueue queue2 = Volley.newRequestQueue(this);
        String url2 = "https://api.nasa.gov/planetary/apod?api_key=NNKOjkoul8n1CH18TWA9gwngW1s1SmjESPjNoUFo";

// Request a string response from the provided URL.
        StringRequest stringRequest2 = new StringRequest(Request.Method.GET, url2,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            // Display the first 500 characters of the response string.

                            JSONObject jObject2 = new JSONObject(response);
                            //You can then extract the entire data array:
                            String str = jObject2.getString("url");
                            String str2 = jObject2.getString("title");
                            Picasso.get().load(str).into(image);
                            text2.setText(str2);
                        } catch (Exception e) {

                        }

                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                text2.setText("That didn't work!");
            }
        });

// Add the request to the RequestQueue.
        queue2.add(stringRequest2);




    }

    @Override
    public void onClick(View v) {
        if(v.getId()==R.id.image)
        {
            Intent myIntent = new Intent(MainActivity.this, photo.class);
            //myIntent.putExtra("key", value); //Optional parameters
            MainActivity.this.startActivity(myIntent);
        }

        if(v.getId()==R.id.more)
        {
            Intent myIntent = new Intent(MainActivity.this, morefacts.class);
            //myIntent.putExtra("key", value); //Optional parameters
            MainActivity.this.startActivity(myIntent);
        }
        if(v.getId()==R.id.math)
        {
            Intent myIntent = new Intent(MainActivity.this, math.class);
            //myIntent.putExtra("key", value); //Optional parameters
            MainActivity.this.startActivity(myIntent);
        }




    }
}