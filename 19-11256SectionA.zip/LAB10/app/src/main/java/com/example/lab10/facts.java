package com.example.lab10;

class facts {
    String fact;


    facts(String fact) {
        this.fact = fact;
    }
}

