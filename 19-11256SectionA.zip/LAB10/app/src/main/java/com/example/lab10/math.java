package com.example.lab10;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

public class math extends AppCompatActivity implements View.OnClickListener {


    TextView eq,fact,resultt;
    String operation,expression,result;
    Button one,two,three,four,five,six,seven,eight,nine,zero,plus,minus,colon,or,pi,power,cos,sin,x,y,submit,open,close,back;
   static int number;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_math);

        eq=findViewById(R.id.eq);
        one=findViewById(R.id.one);
        one.setOnClickListener(this);
        two=findViewById(R.id.two);
        two.setOnClickListener(this);
        three=findViewById(R.id.three);
        three.setOnClickListener(this);
        four=findViewById(R.id.four);
        four.setOnClickListener(this);
        five=findViewById(R.id.five);
        five.setOnClickListener(this);
        six=findViewById(R.id.six);
        six.setOnClickListener(this);
        seven=findViewById(R.id.seven);
        seven.setOnClickListener(this);
        eight=findViewById(R.id.eight);
        eight.setOnClickListener(this);
        nine=findViewById(R.id.nine);
        nine.setOnClickListener(this);
        zero=findViewById(R.id.zero);
        zero.setOnClickListener(this);
        sin=findViewById(R.id.sin);
        sin.setOnClickListener(this);
        cos=findViewById(R.id.cos);
        cos.setOnClickListener(this);
        colon=findViewById(R.id.colon);
        colon.setOnClickListener(this);
        plus=findViewById(R.id.plus);
        plus.setOnClickListener(this);
        minus=findViewById(R.id.minus);
        minus.setOnClickListener(this);
        power=findViewById(R.id.power);
        power.setOnClickListener(this);
        or=findViewById(R.id.or);
        or.setOnClickListener(this);
        pi=findViewById(R.id.pi);
        pi.setOnClickListener(this);
        x=findViewById(R.id.x);
        x.setOnClickListener(this);
        y=findViewById(R.id.y);
        y.setOnClickListener(this);
        submit=findViewById(R.id.submit);
        submit.setOnClickListener(this);
        fact=findViewById(R.id.fact);
        resultt=findViewById(R.id.result);
        open=findViewById(R.id.open);
        open.setOnClickListener(this);
        close=findViewById(R.id.close);
        close.setOnClickListener(this);
        back=findViewById(R.id.back);
        back.setOnClickListener(this);








        Spinner dynamicSpinner = (Spinner) findViewById(R.id.spin);

        String[] items = new String[] { "simplify", "factor", "derive" ,"integrate"
                ,"zeroes","tangent","area","cos","sin","tan",
                "arccos","arcsin","arctan",
                "abs","log" };

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, items);

        dynamicSpinner.setAdapter(adapter);

        dynamicSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {




                operation = parent.getItemAtPosition(position).toString();
                //Log.d("parer", "" + operation);

                Toast.makeText(math.this, parent.getItemAtPosition(position).toString(),

                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });



    }

    @Override
    public void onClick(View v)

    {
        if(v.getId()==R.id.one)
        {
            eq.setText(eq.getText().toString()+1+"");
        }
        if(v.getId()==R.id.two)
        {
            eq.setText(eq.getText().toString()+2+"");
        }
        if(v.getId()==R.id.three)
        {
            eq.setText(eq.getText().toString()+3+"");
        }
        if(v.getId()==R.id.four)
        {
            eq.setText(eq.getText().toString()+4+"");
        }
        if(v.getId()==R.id.five)
        {
            eq.setText(eq.getText().toString()+5+"");
        }
        if(v.getId()==R.id.six)
        {
            eq.setText(eq.getText().toString()+6+"");
        }
        if(v.getId()==R.id.seven)
        {
            eq.setText(eq.getText().toString()+7+"");
        }
        if(v.getId()==R.id.eight)
        {
            eq.setText(eq.getText().toString()+8+"");
        }
        if(v.getId()==R.id.nine)
        {
            eq.setText(eq.getText().toString()+9+"");
        }
        if(v.getId()==R.id.zero)
        {
            eq.setText(eq.getText().toString()+0+"");
        }
        if(v.getId()==R.id.sin)
        {
            eq.setText(eq.getText().toString()+"sin");
        }
        if(v.getId()==R.id.cos)
        {
            eq.setText(eq.getText().toString()+"cos");
        }
        if(v.getId()==R.id.x)
        {
            eq.setText(eq.getText().toString()+"x");
        }
        if(v.getId()==R.id.y)
        {
            eq.setText(eq.getText().toString()+"y");
        }
        if(v.getId()==R.id.colon)
        {
            eq.setText(eq.getText().toString()+":");
        }
        if(v.getId()==R.id.or)
        {
            eq.setText(eq.getText().toString()+"|");
        }
        if(v.getId()==R.id.power)
        {
            eq.setText(eq.getText().toString()+"^");
        }
        if(v.getId()==R.id.pi)
        {
            eq.setText(eq.getText().toString()+"pi");
        }
        if(v.getId()==R.id.plus)
        {
            eq.setText(eq.getText().toString()+"+");
        }
        if(v.getId()==R.id.minus)
        {
            eq.setText(eq.getText().toString()+"-");
        }
        if(v.getId()==R.id.open)
        {
            eq.setText(eq.getText().toString()+"(");
        }
        if(v.getId()==R.id.close)
        {
            eq.setText(eq.getText().toString()+")");
        }
        if(v.getId()==R.id.back)
        {
            eq.setText("");
        }

        if(v.getId()==R.id.submit)
        {
            expression = eq.getText().toString();





            RequestQueue queue = Volley.newRequestQueue(this);
            String url ="https://newton.now.sh/"+operation+"/"+expression;

// Request a string response from the provided URL.
            StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            try {
                                // Display the first 500 characters of the response string.

                                JSONObject jObject = new JSONObject(response);
                                //You can then extract the entire data array:
                                // Log.d("p", "" + jObject.getString("text"));
                                result = jObject.getString("result");
                                number = jObject.getInt("result");
                                resultt.setText(result);
                                RequestQueue queue2 = Volley.newRequestQueue(math.this);
                                String url2 = "http://numbersapi.com/"+number+"/math?json";

// Request a string response from the provided URL.
                                StringRequest stringRequest2 = new StringRequest(Request.Method.GET, url2,
                                        new Response.Listener<String>() {
                                            @Override
                                            public void onResponse(String response) {

                                                try {
                                                    // Display the first 500 characters of the response string.

                                                    JSONObject jObject2 = new JSONObject(response);
                                                    //You can then extract the entire data array:
                                                    //Log.d("pot", "" + jObject2.getString("url"));
                                                    String facte = jObject2.getString("text");
                                                    //String str2 = jObject2.getString("title");
                                                    // Picasso.get().load(str).into(image);
                                                    //text2.setText(str2);
                                                    fact.setText(facte);

                                                } catch (Exception e) {
                                                    fact.setText("didnt work");

                                                }

                                            }

                                        }, new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError error) {
                                        fact.setText("That didn't work!");
                                    }
                                });

// Add the request to the RequestQueue.
                                queue2.add(stringRequest2);
                               // Log.d("pooor", "" + jObject.getString("text"));
                                //Log.d("pooopr", "" + number);

                               // Log.d("pooopr", "" + result);

                                //text.setText(str);
                            }
                            catch(Exception e)
                            {

                            }

                        }

                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    //text.setText("That didn't work!");
                }
            });

// Add the request to the RequestQueue.
            queue.add(stringRequest);


        }


    }
}
