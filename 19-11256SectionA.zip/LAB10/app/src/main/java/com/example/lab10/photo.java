package com.example.lab10;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

public class photo extends AppCompatActivity {

    TextView title,desc,date,cp;
    ImageView image;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo);

        title=findViewById(R.id.title);
        desc=findViewById(R.id.desc);
        date=findViewById(R.id.date);
        cp=findViewById(R.id.cp);
        image=findViewById(R.id.image);




        RequestQueue queue2 = Volley.newRequestQueue(this);
        String url = "https://api.nasa.gov/planetary/apod?api_key=NNKOjkoul8n1CH18TWA9gwngW1s1SmjESPjNoUFo";


        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        try {
                            // Display the first 500 characters of the response string.

                            JSONObject jObject = new JSONObject(response);
                            //You can then extract the entire data array:

                            String hdphoto = jObject.getString("hdurl");
                            String titlea = jObject.getString("title");
                            String explanation = jObject.getString("explanation");
                            String datee = jObject.getString("date");
                            title.setText(titlea);
                            Picasso.get().load(hdphoto).into(image);
                            desc.setText(explanation);
                            date.setText(datee);

                        } catch (Exception e) {

                        }

                    }

                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                title.setText("That didn't work!");
            }
        });

// Add the request to the RequestQueue.
        queue2.add(stringRequest);

    }
}
